function calculateCost() {
    const length = parseFloat(document.getElementById('length').value);
    const width = parseFloat(document.getElementById('width').value);
    const height = parseFloat(document.getElementById('height').value);
    const rateSea = parseFloat(document.getElementById('rate_sea').value);
    const rateAir = parseFloat(document.getElementById('rate_air').value);
    const transportType = document.querySelector('input[name="transport_type"]:checked').value;

    let cost;
    let resultMessage;

    if (transportType === 'دریایی') {
        const volumetricWeightSea = (length * width * height) / 1000000;
        cost = volumetricWeightSea * rateSea;
        resultMessage = `وزن حجمی بار: ${volumetricWeightSea.toFixed(2)} متر مکعب<br>`;
    } else if (transportType === 'هوایی') {
        const volumetricWeightAir = (length * width * height) / 6000;
        cost = volumetricWeightAir * rateAir;
        resultMessage = `وزن جرمی بار: ${volumetricWeightAir.toFixed(2)} کیلوگرم<br>`;
    }

    resultMessage += `هزینه حمل و نقل ${transportType} برای باری با ابعاد ${length}x${width}x${height} سانتی‌متر: ${cost.toFixed(2)} دلار است.`;
    document.getElementById('result').innerHTML = resultMessage;
}